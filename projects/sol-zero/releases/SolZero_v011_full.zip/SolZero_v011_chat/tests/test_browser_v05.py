"""Browser-level acceptance tests on the self-contained offline HTML (mobile + desktop)."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'SolZero_Chat_Offline.html').read_text(encoding='utf-8')

def start(page):
    page.evaluate("""() => {
      const data = window.__test_storage || {};
      window.__test_storage = data;
      Object.defineProperty(window, 'localStorage', {configurable:true, value:{
        getItem:(k)=>data[k] ?? null,
        setItem:(k,v)=>{data[k]=String(v)},
        removeItem:(k)=>{delete data[k]}
      }});
    }""")
    page.set_content(HTML)
    page.get_by_text('Sol-Zero へようこそ').wait_for()

def send(page,text):
    page.locator('#input').fill(text)
    page.locator('#send').click()

def main():
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        ctx=browser.new_context(viewport={'width':393,'height':852},accept_downloads=True)
        page=ctx.new_page();page.set_default_timeout(5000);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
        print('TEST start(page)',flush=True)
        start(page)
        print("TEST send(page,'計算して 8*(4+1)')",flush=True)
        send(page,'計算して 8*(4+1)')
        assert page.get_by_text('計算結果：40').is_visible()
        send(page,'/todo テスト資料を作る')
        send(page,'/done 1')
        assert page.get_by_text('☑ テスト資料を作る',exact=False).is_visible()
        send(page,'覚えて：プロジェクトA')
        send(page,'覚えていること')
        assert page.get_by_text('メモ（1件）',exact=False).is_visible()

        print("TEST page.locator('#knowledgeBtn').click()",flush=True)
        page.locator('#knowledgeBtn').click()
        assert page.get_by_text('共有知識を教える').is_visible()
        page.get_by_label('質問（120文字以内）').fill('本日の実験番号は？')
        page.get_by_label('回答（1500文字以内）').fill('TEST-42')
        page.get_by_text('知識を登録',exact=True).click()
        assert page.get_by_text('本日の実験番号は？').is_visible()
        page.locator('#closePanel').click()
        send(page,'本日の実験番号は？')
        assert page.locator('#messages .bubble').get_by_text('TEST-42',exact=True).last.is_visible()

        # Document added from local bytes; no internet request.
        print("TEST page.locator('#docsBtn').click()",flush=True)
        page.locator('#docsBtn').click()
        page.locator('#docPicker').set_input_files(files=[{
          'name':'scratch_notes.md','mimeType':'text/markdown','buffer':'報告番号：4\n断面積は300平方センチ\n完了しました'.encode('utf-8')
        }])
        page.get_by_text('scratch_notes.md').wait_for()
        page.locator('#closePanel').click()
        send(page,'/search 断面積')
        assert page.get_by_text('scratch_notes.md 2行目',exact=False).is_visible()

        # Local data is present after re-creating the page DOM.
        count=page.locator('.message').count()
        assert count>=14,count
        page.screenshot(path=str(ROOT/'artifacts'/'mobile_v05.png'),full_page=True)
        print('TEST page.set_content(HTML)',flush=True)
        page.set_content(HTML)
        page.locator('.message').first.wait_for()
        assert page.locator('.message').count()==count
        send(page,'本日の実験番号は？')
        assert page.locator('#messages .bubble').get_by_text('TEST-42',exact=True).count()>=2

        # Backup download and menu navigation.
        print("TEST page.locator('#menu').click()",flush=True)
        page.locator('#menu').click()
        assert page.locator('#sidebar.open').is_visible()
        with page.expect_download() as info:page.locator('#exportJson').click()
        obj=json.loads(Path(info.value.path()).read_text(encoding='utf-8'))
        assert obj['schema']==3
        assert len(obj['knowledge'])==1 and len(obj['documents'])==1
        # Corrupt-looking user input stays text, never interpreted as HTML.
        send(page,'<img src=x onerror=window.__sol_xss=1>')
        assert page.evaluate('window.__sol_xss === undefined')
        # Restore the exported snapshot; dialog confirmation is required.
        page.locator('#menu').click()
        page.locator('#importJson').click()
        page.once('dialog',lambda dialog:dialog.accept())
        page.locator('#jsonPicker').set_input_files(files=[{
          'name':'restore.json','mimeType':'application/json',
          'buffer':json.dumps(obj,ensure_ascii=False).encode('utf-8')
        }])
        assert page.locator('.message').count()==count+2
        assert page.evaluate('window.__sol_xss === undefined')
        print("TEST page.locator('#menu').click()",flush=True)
        page.locator('#menu').click()
        page.locator('#newTop').click()
        assert page.get_by_text('Sol-Zero へようこそ').is_visible()
        send(page,'本日の実験番号は？')
        assert page.locator('#messages .bubble').get_by_text('TEST-42',exact=True).last.is_visible()
        assert not errors,errors

        # Desktop: WSP interactive patch and rollback.
        desktop=browser.new_context(viewport={'width':1280,'height':900})
        desk=desktop.new_page();desk.set_default_timeout(5000);deskerrors=[];desk.on('pageerror',lambda e:deskerrors.append(str(e)))
        start(desk)
        print("TEST desk.locator('#circuitBtn').click()",flush=True)
        desk.locator('#circuitBtn').click()
        assert desk.get_by_text('WSP 重み編集').is_visible()
        desk.get_by_label('出力カテゴリ').select_option('identity')
        desk.get_by_label('入力特徴').select_option('gratitude')
        desk.get_by_label('設定する重み（−100〜100）').fill('15')
        desk.get_by_text('重みを直接設定').click()
        assert desk.get_by_text('検出カテゴリ：identity',exact=False).is_visible()
        desk.get_by_text('前回の変更を取り消す').click()
        assert desk.get_by_text('検出カテゴリ：gratitude',exact=False).is_visible()
        desk.screenshot(path=str(ROOT/'artifacts'/'desktop_wsp_v05.png'),full_page=True)
        assert not deskerrors,deskerrors
        print(json.dumps({'mobile':'PASS','desktop':'PASS','messages':count,'global_qa':'PASS','documents':'PASS','persistence':'PASS','backup':'PASS','wsp':'PASS','browser_errors':errors+deskerrors},ensure_ascii=False))
        desktop.close();ctx.close();browser.close()

if __name__=='__main__':main()
