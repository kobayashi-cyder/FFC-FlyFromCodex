import {auditFactory,FACTORY_FAMILIES} from '../chat_web/wsp_factory.js';
import fs from 'node:fs';
const since=performance.now();
let circuits=0,correct=0,failed=0,total=0,weightTotal=0,errors=[];
for(let start=0;start<65536;start+=512){
  const report=auditFactory('lut4',start,512);
  circuits+=report.count;correct+=report.passed;failed+=report.failed;
  total+=report.verifiedCases;weightTotal+=report.virtualWeightCount;
  if(report.errors.length)errors.push(...report.errors);
}
const results={generator:'scratch WSP 4-input boolean truth-table compiler',total_functions:circuits,passed_functions:correct,failed_functions:failed,boolean_inputs_checked:total,virtual_weight_occurrences:weightTotal,stored_all_at_once:false,all_verification_from_spec:true,external_pretrained_weights:false,wall_time_seconds:Number(((performance.now()-since)/1000).toFixed(3)),errors:errors.slice(0,12)};
fs.writeFileSync(new URL('../artifacts/lut4_all_65536.json',import.meta.url),JSON.stringify(results,null,2));
console.log(JSON.stringify(results,null,2));if(failed>0||total!==65536*16)process.exit(1);
