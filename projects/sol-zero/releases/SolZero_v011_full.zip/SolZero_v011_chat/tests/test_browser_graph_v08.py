"""Integration of WSP graph editor, messages, migration, no external requests."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'SolZero_Chat_Offline.html').read_text('utf-8')


def run():
  with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    ctx=browser.new_context(viewport={'width':393,'height':852},accept_downloads=True,is_mobile=True,device_scale_factor=1)
    page=ctx.new_page();page.set_default_timeout(12000)
    errors=[];external=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:external.append(r.url) if r.url.startswith(('https://','http://')) else None)
    page.evaluate('''() => {
      window.__fake={};Object.defineProperty(window,'localStorage',{configurable:true,value:{
        getItem:k=>window.__fake[k]??null,
        setItem:(k,v)=>{window.__fake[k]=String(v)},
        removeItem:k=>delete window.__fake[k]
      }});
    }''')
    page.set_content(HTML)
    page.get_by_text('Sol-Zero へようこそ').wait_for()
    page.locator('#graphBtn').click()
    assert page.get_by_text('WSP 汎用グラフ／重み空間',exact=True).is_visible()
    page.get_by_text('現在の回路を実行').click()
    assert '"xor":[1]' in page.locator('#panelBody .listentry').last.inner_text()
    page.get_by_text('真理値表 → 回路生成').click()
    assert '真理値表 8/8 正解' in page.locator('#panelBody .listentry').last.inner_text()
    page.get_by_text('① JSON回路を独立テスト').click()
    assert '独立テスト：8/8' in page.locator('#panelBody .listentry').last.inner_text()
    page.get_by_text('② 回路を適用').click()
    assert '回路を適用・保存しました' in page.locator('#panelBody .listentry').last.inner_text()
    page.locator('#closePanel').click()
    page.locator('#input').fill('/graph 1,1,1')
    page.locator('#send').click()
    assert '"output":[1]' in page.locator('#messages').inner_text()
    page.locator('#graphBtn').click()
    page.get_by_text('回路を元に戻す').click()
    assert '直前の重み空間に戻しました' in page.locator('#panelBody .listentry').last.inner_text()
    page.locator('#closePanel').click()
    page.locator('#input').fill('/graph 1,0')
    page.locator('#send').click()
    assert '"xor":[1]' in page.locator('#messages').inner_text()
    page.locator('#graphBtn').click()
    # Current graph is XOR; explicitly set a weight then undo.
    page.get_by_text('数値重みを直接編集').click()
    assert '編集した重み' in page.locator('#panelBody .listentry').last.inner_text()
    page.get_by_text('回路を元に戻す').click()
    assert '直前の重み空間に戻しました' in page.locator('#panelBody .listentry').last.inner_text()
    # Dense generation should not auto-install or claim trained intelligence.
    page.get_by_text('任意サイズの重みを生成').click()
    assert '未学習の密行列' in page.locator('#panelBody .listentry').last.inner_text()
    page.locator('#closePanel').click()
    # Backup contains graph and restores it, including after reload.
    page.locator('#menu').click()
    with page.expect_download() as dl:page.locator('#exportJson').click()
    data=json.loads(Path(dl.value.path()).read_text('utf-8'))
    assert data['app_version']=='0.8.0'
    assert data['graph']['name'].startswith('WSP XOR')
    page.set_content(HTML)
    page.locator('#input').fill('/graph 0,1')
    page.locator('#send').click()
    assert '"xor":[1]' in page.locator('#messages').inner_text()
    # Mobile screenshot & messages.
    page.locator('#graphBtn').click()
    page.screenshot(path=str(ROOT/'artifacts'/'mobile_wsp_v08.png'),full_page=True)
    page.locator('#closePanel').click()
    # Legacy data migration from v0.7
    migrated={'schema':3,'chats':[{'id':'legacy','title':'旧版','created':'2026-11-05T00:00:00Z','messages':[{'role':'user','text':'移行できる？','at':'2026-11-05T00:00:00Z'}],'draft':'','notes':[],'lessons':[],'tasks':[]}],'current':'legacy','knowledge':[],'documents':[],'theme':'light'}
    page.evaluate('''v=>{delete window.__fake['solzero_chat_v08_local'];window.__fake['solzero_chat_v07_local']=JSON.stringify(v)}''',migrated)
    page.set_content(HTML)
    assert '移行できる？' in page.locator('#messages').inner_text()
    assert not errors,errors
    assert not external,external
    report={'mobile':True,'graph':'XOR+parity+custom weights+undo+backup+reload','migration':'v0.7 to v0.8','networkRequests':external,'pageErrors':errors,'passed':True}
    (ROOT/'artifacts'/'browser_graph_v08.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps(report,ensure_ascii=False));browser.close()
if __name__=='__main__':run()
