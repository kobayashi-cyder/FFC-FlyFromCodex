"""Chromium WSP 4096 rule stress test, no external requests."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'SolZero_Chat_Offline.html').read_text('utf-8')
with sync_playwright() as pw:
    b=pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=b.new_page(viewport={'width':393,'height':852});page.set_default_timeout(30000)
    errors=[];remote=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:remote.append(r.url) if r.url.startswith(('https://','http://')) else None)
    page.evaluate('''() => {
      const store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{
       getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]}});
    }''')
    page.set_content(HTML)
    page.locator('#bulkBtn').click()
    page.get_by_text('4,096件の規模試験を生成').click()
    stats=page.locator('#panelBody .listentry').first.inner_text()
    assert '4,096 ルール' in stats, stats
    page.get_by_label('回路に入力して検査').fill('検証キー3871')
    page.get_by_text('ニューロン発火を検査').click()
    text=page.locator('#panelBody .listentry').nth(1).inner_text()
    assert 'synthetic_3871' in text,text
    with page.expect_download() as d:
      page.locator('#closePanel').click();page.locator('#menu').click();page.locator('#exportJson').click()
    record=json.loads(Path(d.value.path()).read_text('utf-8'))
    size_bytes= len(json.dumps(record,ensure_ascii=False).encode('utf-8'))
    assert len(record['bulk']['rules'])==4096
    assert size_bytes<1_000_000
    assert not remote and not errors,(remote,errors)
    result={'compiled_rules':4096,'matched_neuron':'synthetic_3871','backup_bytes':size_bytes,'remote':remote,'errors':errors}
    (ROOT/'artifacts'/'browser_stress_v06.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps(result,ensure_ascii=False))
    b.close()
