"""v0.5 offline/browser acceptance: model learning, heldout, generation, WSP patch, migration."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'SolZero_Chat_Offline.html').read_text(encoding='utf-8')

def start(page):
    page.evaluate("""() => {
      const data = window.__test_storage || {};
      window.__test_storage = data;
      Object.defineProperty(window, 'localStorage', {configurable:true, value:{
        getItem:(k)=>data[k] ?? null,
        setItem:(k,v)=>{data[k]=String(v)},
        removeItem:(k)=>{delete data[k]}
      }});
    }""")
    page.set_content(HTML)
    page.get_by_text('Sol-Zero へようこそ').wait_for()

def send(page,text):
    page.locator('#input').fill(text);page.locator('#send').click()

def main():
  with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    ctx=browser.new_context(viewport={'width':393,'height':852},accept_downloads=True)
    page=ctx.new_page();page.set_default_timeout(10000)
    errors=[]; requests=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:requests.append(r.url))
    start(page)
    assert page.locator('#generatorBtn').is_visible()
    page.locator('#generatorBtn').click()
    assert page.get_by_text('生成実験：ゼロから学習').is_visible()
    corpus='あしたは晴れです。あしたは雨です。'.__mul__(12)
    page.get_by_label('学習文章（8〜10,000文字・最大96種類）').fill(corpus)
    page.get_by_label('学習回数（1〜20）').fill('6')
    page.get_by_text('文章から学習する').click()
    assert page.locator('#panelBody').get_by_text('学習文章の損失',exact=False).is_visible()
    page.get_by_label('評価用文章（学習と異なる文章を入力）').fill('あしたは晴れです。')
    page.get_by_text('未学習文章で評価').click()
    assert page.locator('#panelBody').get_by_text('未学習文章の平均損失',exact=False).is_visible()
    page.get_by_text('文字を生成').click()
    assert page.locator('#panelBody').get_by_text('実験用の1文字予測',exact=False).is_visible()
    page.get_by_label('直接編集：直前の文字').fill('あ')
    page.get_by_label('直接編集：次の文字').fill('し')
    page.get_by_label('重みの値（−30〜30）').fill('4')
    page.get_by_text('遷移重みを直接変更').click()
    page.get_by_text('直前の編集を戻す').click()
    page.screenshot(path=str(ROOT/'artifacts'/'mobile_generator_v05.png'),full_page=True)
    page.locator('#closePanel').click()
    send(page,'/model')
    assert page.locator('#messages').get_by_text('スクラッチ文字予測モデル',exact=False).is_visible()
    send(page,'/generate あ')
    assert page.locator('#messages').get_by_text('実験的な文字予測',exact=False).is_visible()

    # A prior conversation keeps unsent draft on switching to new conversation.
    page.locator('#input').fill('書きかけの下書きを保存')
    page.locator('#newTop').click()
    assert page.locator('#input').input_value()==''
    page.locator('#menu').click()
    page.locator('#history .chat-nav').last.click()
    assert page.locator('#input').input_value()=='書きかけの下書きを保存'
    page.locator('#menu').click()
    page.locator('#pinChat').click()
    assert page.locator('#pinChat').inner_text()=='📌 固定を解除'
    assert '📌' in page.locator('#history .chat-nav').first.inner_text()

    # v0.5 snapshot includes trained weight-space and the pinned draft.
    with page.expect_download() as download:
        page.locator('#exportJson').click()
    archive=json.loads(Path(download.value.path()).read_text('utf-8'))
    assert archive['schema']==3 and archive['generator']['steps']>0
    assert archive['chats'][0]['pinned'] or archive['chats'][1]['pinned']
    assert archive['generator']['vocab']
    page.set_content(HTML)
    page.locator('#input').wait_for()
    send(page,'/model')
    assert page.locator('#messages').get_by_text('スクラッチ文字予測モデル',exact=False).last.is_visible()

    # evidence search must quote actual document line, not generate invented facts
    page.locator('#docsBtn').click()
    page.locator('#docPicker').set_input_files(files=[{
      'name':'inspection.md','mimeType':'text/markdown',
      'buffer':'安全確認\n動作条件：最高温度38度\n試験時刻：12:00'.encode('utf-8')
    }])
    page.get_by_text('inspection.md').wait_for()
    page.locator('#closePanel').click()
    send(page,'/ask 動作条件')
    assert page.locator('#messages').get_by_text('inspection.md 2行目',exact=False).last.is_visible()
    assert not errors,errors
    assert not requests,requests
    print(json.dumps({'trained_steps':archive['generator']['steps'], 'vocab':len(archive['generator']['vocab']),
      'generator':'PASS','scratch_weights':'PASS','holdout_eval':'PASS','wsp_rollback':'PASS',
      'draft':'PASS','pin':'PASS','persistence':'PASS','evidence':'PASS','network_requests':requests,'errors':errors},ensure_ascii=False))
    browser.close()
if __name__=='__main__':main()
