"""Mobile browser integration for v0.9 single-file WSP factory and migration."""
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'SolZero_Chat_Offline.html').read_text('utf-8')

def run():
    with sync_playwright() as pw:
        browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':393,'height':852},device_scale_factor=1,is_mobile=True,accept_downloads=True)
        page=context.new_page();page.set_default_timeout(12000)
        errors=[];requests=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.on('request',lambda req:requests.append(req.url) if req.url.startswith(('https://','http://')) else None)
        page.evaluate('''() => {
          window.__localCopy={};Object.defineProperty(window,'localStorage',{configurable:true,value:{
           getItem:key=>window.__localCopy[key]??null,
           setItem:(key,v)=>{window.__localCopy[key]=String(v)},
           removeItem:key=>{delete window.__localCopy[key]}
          }});
        }''')
        page.set_content(HTML)
        page.get_by_text('Sol-Zero へようこそ').wait_for()
        page.locator('#factoryBtn').click()
        assert page.get_by_text('WSP 回路工房 v0.9',exact=True).is_visible()
        assert '65,536' in page.locator('#panelBody').inner_text()
        page.locator('#factoryFamily').select_option('lut4')
        numeric=page.locator('#factoryFamily').locator('xpath=following::input[1]')
        assert numeric.input_value()=='0' or numeric.input_value()=='43690'
        numeric.fill('43690')
        page.get_by_text('回路生成',exact=True).click()
        page.get_by_text('仕様照合テスト',exact=True).click()
        assert '16/16 件正解' in page.locator('#panelBody').inner_text()
        page.get_by_text('合格回路をチャットへ適用',exact=True).click()
        assert 'WSPグラフへ適用' in page.locator('#panelBody').inner_text()
        page.get_by_text('指定範囲の大量回路を実生成・テスト',exact=True).click()
        assert '128/128 回路合格' in page.locator('#panelBody').inner_text()
        page.get_by_text('合成回路を検証',exact=True).click()
        assert '10/10' in page.locator('#panelBody').inner_text()
        page.get_by_text('合格した合成回路を適用',exact=True).click()
        assert '異種回路 3段' in page.locator('#panelBody').inner_text()
        page.screenshot(path=str(ROOT/'artifacts'/'mobile_factory_v09.png'),full_page=True)
        page.locator('#closePanel').click()
        page.locator('#input').fill('/factory lut4 43690 0 1 0 1')
        page.locator('#send').click()
        assert 'output' in page.locator('#messages').inner_text()
        page.locator('#input').fill('/graph 1')
        page.locator('#send').click()
        assert 'WSPグラフ出力' in page.locator('#messages').inner_text()
        page.locator('#menu').click()
        with page.expect_download() as dl:page.locator('#exportJson').click()
        data=json.loads(Path(dl.value.path()).read_text('utf-8'))
        assert data['app_version']=='0.9.0',data['app_version']
        assert 'graph' in data and data['graph']['name'].startswith('WSP pipeline')
        page.set_content(HTML)
        page.locator('#input').fill('/factory affine2 8 1 2')
        page.locator('#send').click()
        assert '2変数一次関数' in page.locator('#messages').inner_text()
        # v0.8 data import via versioned local storage; no history lost.
        prev={'schema':3,'chats':[{'id':'v08-old','title':'v08のチャット','created':'2026-11-06T00:00:00Z',
             'messages':[{'role':'user','text':'v0.8で保存したメッセージ','at':'2026-11-06T00:00:00Z'}]}],
             'current':'v08-old','knowledge':[],'documents':[],'theme':'dark'}
        page.evaluate("v=>{delete window.__localCopy['solzero_chat_v09_local'];window.__localCopy['solzero_chat_v08_local']=JSON.stringify(v)}",prev)
        page.set_content(HTML)
        assert 'v0.8で保存したメッセージ' in page.locator('#messages').inner_text()
        assert not errors,errors
        assert not requests,requests
        report={'version':'0.9.0','mobile':True,'factory':'65k Boolean indexed + batch128 + pipeline3',
                'legacy_migration':'v0.8 to v0.9','errors':errors,'http_requests':requests,'passed':True}
        (ROOT/'artifacts'/'browser_factory_v09.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
        print(json.dumps(report,ensure_ascii=False))
        browser.close()

if __name__=='__main__':run()
