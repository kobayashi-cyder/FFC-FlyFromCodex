"""Strict package-size check; refuses symlinks and the 5 decimal GB cap."""
from pathlib import Path
import json
import sys
CAP = 5_000_000_000


def audit(root):
    p=Path(root)
    if not p.exists():raise FileNotFoundError(p)
    entries=[]
    for f in p.rglob('*'):
        if f.is_symlink():raise ValueError('symlink prohibited in a distribution')
        if f.is_file():entries.append({'name':str(f.relative_to(p)),'bytes':f.stat().st_size})
    total=sum(x['bytes'] for x in entries)
    if total>CAP:raise ValueError('distribution exceeds 5GB')
    return {'limit_bytes':CAP,'total_file_bytes':total,'file_count':len(entries),'within_budget':True}


if __name__=='__main__':
    print(json.dumps(audit(sys.argv[1] if len(sys.argv)>1 else Path(__file__).resolve().parents[1]),indent=2))
