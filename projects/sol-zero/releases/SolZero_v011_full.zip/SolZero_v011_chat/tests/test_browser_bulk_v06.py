"""Browser acceptance for zero-pretrained WSP compiler, backup, patch and UI."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=ROOT/'SolZero_Chat_Offline.html'

def send(page,text):
    page.locator('#input').fill(text)
    page.locator('#send').click()

def run():
  with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    ctx=browser.new_context(viewport={'width':393,'height':852},accept_downloads=True)
    page=ctx.new_page();page.set_default_timeout(12000)
    errors=[]; http=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:http.append(r.url) if r.url.startswith(('http://','https://')) else None)
    page.evaluate('''() => {
      const data = window.__test_storage || {};
      window.__test_storage = data;
      Object.defineProperty(window, 'localStorage', {configurable:true, value:{
        getItem:(k)=>data[k] ?? null,
        setItem:(k,v)=>{data[k]=String(v)},
        removeItem:(k)=>{delete data[k]}
      }});
    }''')
    page.set_content(HTML.read_text(encoding='utf-8'))
    page.get_by_text('Sol-Zero へようこそ').wait_for()
    page.locator('#bulkBtn').click()
    page.get_by_text('WSP 大量回路コンパイラ').wait_for()
    page.get_by_text('サンプル6ルールを表示').click()
    page.get_by_text('JSONを一括コンパイル').click()
    assert '6 ルール' in page.locator('#panelBody .listentry').first.inner_text()
    page.get_by_label('回路に入力して検査').fill('計画の手順を整理したい')
    page.get_by_text('ニューロン発火を検査').click()
    assert 'demo_plan' in page.locator('#panelBody .listentry').nth(1).inner_text()
    page.get_by_label('接続された特徴量').fill('計画')
    page.get_by_label('新しい整数重み -5〜5').fill('0')
    page.get_by_text('接続重みを直接書き込む').click()
    assert '直接編集' in page.locator('#panelBody .listentry').nth(1).inner_text()
    page.get_by_text('重みの編集を1件戻す').click()
    assert '復元しました' in page.locator('#panelBody .listentry').nth(1).inner_text()
    # Workflow neural FSM is compiled from numeric input gates.
    page.get_by_text('状態機械サンプルを表示').click()
    page.get_by_text('遷移回路をコンパイル').click()
    page.get_by_label('遷移イベント名').fill('開始')
    page.get_by_text('イベントを実行（文字だけ）').click()
    assert '待機 → 計画' in page.locator('#panelBody .listentry').last.inner_text()
    page.get_by_text('前の状態へ戻す').click()
    assert '状態を1つ戻しました' in page.locator('#panelBody .listentry').last.inner_text()
    page.screenshot(path=str(ROOT/'artifacts'/'mobile_wsp_v06.png'),full_page=True)
    page.locator('#closePanel').click()
    send(page,'計画の手順が必要です')
    assert 'WSP直接構築回路：demo_plan' in page.locator('#messages').inner_text()
    send(page,'/flow')
    assert '現在「待機」' in page.locator('#messages').inner_text()
    send(page,'/wsp')
    assert '6ルール' in page.locator('#messages').inner_text()
    with page.expect_download() as download:
      page.locator('#menu').click();page.locator('#exportJson').click()
    record=json.loads(Path(download.value.path()).read_text('utf-8'))
    assert len(record['bulk']['rules'])==6
    assert len(record['flow']['transitions'])==6
    assert record['app_version']=='0.6.0'
    # localStorage survives a reload with same WSP identity
    page.set_content(HTML.read_text(encoding='utf-8'));page.locator('#input').wait_for()
    send(page,'計画の手順が必要です')
    assert 'WSP直接構築回路：demo_plan' in page.locator('#messages').inner_text()
    # malformed input must preserve the previous rules
    page.locator('#bulkBtn').click()
    page.get_by_label('JSONルール配列（書き換え後に「コンパイル」を押す）').fill('[{"id":"broken","all":[],"response":"none"}]')
    page.get_by_text('JSONを一括コンパイル').click()
    assert '拒否' in page.locator('#panelBody .listentry').nth(1).inner_text()
    assert '6 ルール' in page.locator('#panelBody .listentry').first.inner_text()
    # deleted rule set and undo should work
    page.get_by_label('JSONルール配列（書き換え後に「コンパイル」を押す）').fill('[]')
    page.get_by_text('JSONを一括コンパイル').click()
    assert '0 ルール' in page.locator('#panelBody .listentry').first.inner_text()
    page.get_by_text('直前の一括更新を取り消す').click()
    assert '6 ルール' in page.locator('#panelBody .listentry').first.inner_text()
    page.locator('#closePanel').click()
    assert not errors,errors
    assert not http,http
    print(json.dumps({'wsp_bulk':'PASS','mobile_ui':'PASS','direct_edit_rollback':'PASS',
     'chat_integration':'PASS','wsp_fsm':'PASS','persistence':'PASS','reject_atomic':'PASS',
     'json_backup':'PASS','http_requests':http,'errors':errors},ensure_ascii=False))
    browser.close()
if __name__=='__main__':run()
