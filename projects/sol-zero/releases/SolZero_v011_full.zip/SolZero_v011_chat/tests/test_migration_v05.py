"""Old v0.4 snapshot is migrated locally without external calls."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'SolZero_Chat_Offline.html').read_text('utf-8')
with sync_playwright() as pw:
  b=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  p=b.new_page(viewport={'width':390,'height':844});errors=[]
  p.on('pageerror',lambda e:errors.append(str(e)))
  old={'schema':2,'chats':[{'id':'abc123','title':'移行確認','created':'2026-11-01T00:00:00Z','messages':[{'role':'user','text':'前の発言','at':'2026-11-01T00:00:00Z'}],'notes':['古いメモ'],'lessons':[],'tasks':[]}],
       'current':'abc123','knowledge':[{'q':'旧版の番号','a':'v04'}], 'documents':[],'theme':'dark','wsp':None}
  p.evaluate("""x => {
    const store={'solzero_chat_v04_local':JSON.stringify(x)};
    window.__solstore=store;
    Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>store[k]??null,setItem:(k,v)=>{store[k]=v},removeItem:k=>delete store[k]}});
  }""",old)
  p.set_content(HTML)
  p.locator('#messages .message').first.wait_for()
  assert p.get_by_text('前の発言').is_visible()
  assert p.evaluate("document.documentElement.dataset.theme")=='dark'
  p.locator('#input').fill('旧版の番号');p.locator('#send').click()
  assert p.locator('#messages').get_by_text('v04',exact=True).is_visible()
  saved=json.loads(p.evaluate("window.__solstore['solzero_chat_v06_local']"))
  assert saved['schema']==3 and saved['chats'][0]['draft']==''
  assert saved['knowledge'][0]['a']=='v04' and saved['generator']['steps']==0
  assert not errors,errors
  print(json.dumps({'v04_to_v06':'PASS','history_preserved':'PASS','knowledge_preserved':'PASS','theme_preserved':'PASS','errors':errors},ensure_ascii=False))
  b.close()
