"""End-to-end mobile/desktop verification, v0.6 data migration, no network."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'SolZero_Chat_Offline.html').read_text(encoding='utf-8')
def attach_storage(page, data):
    page.evaluate('''data => {
      window.__test_storage = data;
      Object.defineProperty(window,'localStorage',{configurable:true,value:{
        getItem:k=>window.__test_storage[k] ?? null,
        setItem:(k,v)=>{window.__test_storage[k]=String(v)},
        removeItem:k=>{delete window.__test_storage[k]}
      }});
    }''',data)

def send(page,txt):
    page.locator('#input').fill(txt)
    page.locator('#send').click()

def run():
  with sync_playwright() as pw:
    browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    ctx=browser.new_context(viewport={'width':393,'height':852},accept_downloads=True)
    p=ctx.new_page();p.set_default_timeout(8000)
    errors=[];net=[]
    p.on('pageerror',lambda e:errors.append(str(e)))
    p.on('request',lambda r:net.append(r.url) if r.url.startswith(('https://','http://')) else None)
    attach_storage(p,{})
    p.set_content(HTML)
    p.get_by_text('Sol-Zero へようこそ').wait_for()
    assert p.locator('#autoBtn').is_visible()
    p.locator('#autoBtn').click()
    assert p.get_by_text('WSP 自動設計・独立検証').is_visible()
    p.get_by_text('① 自動設計と独立検証').click()
    assert '合格（採用可能）' in p.locator('#panelBody .listentry').nth(1).inner_text()
    p.once('dialog',lambda d:d.accept())
    p.get_by_text('② 合格した回路を採用',exact=True).click()
    assert '採用しました' in p.locator('#panelBody .listentry').nth(1).inner_text()
    p.locator('#closePanel').click()
    send(p,'おはよう、今日もよろしく')
    assert 'WSP直接構築回路：auto_' in p.locator('#messages').inner_text()
    send(p,'/auto')
    assert '独立評価 4/4' in p.locator('#messages').inner_text()
    p.locator('#autoBtn').click()
    textarea=p.get_by_label('問題の仕様（JSON：train=構築用、validation=独立評価用）')
    spec=json.loads(textarea.input_value())
    spec['validation'][0]['output']='計算'  # Deliberate holdout mismatch
    textarea.fill(json.dumps(spec,ensure_ascii=False))
    p.get_by_text('① 自動設計と独立検証').click()
    assert '不合格（採用不可）' in p.locator('#panelBody .listentry').nth(1).inner_text()
    p.get_by_text('② 合格した回路を採用',exact=True).click()
    assert '採用不可' in p.locator('#panelBody .listentry').nth(1).inner_text()
    p.locator('#closePanel').click()
    send(p,'エラーを修正したい')
    assert 'WSP直接構築回路：auto_' in p.locator('#messages').inner_text()
    p.locator('#autoBtn').click()
    p.get_by_text('① 遷移回路候補を作成').click()
    assert '生成候補' in p.locator('#panelBody .listentry').last.inner_text()
    p.once('dialog',lambda d:d.accept())
    p.get_by_text('② 状態機械へ採用').click()
    assert '採用しました' in p.locator('#panelBody .listentry').last.inner_text()
    p.locator('#closePanel').click()
    send(p,'/flow event 開始')
    assert '待機 → 分析' in p.locator('#messages').inner_text()
    p.locator('#autoBtn').click()
    p.get_by_text('以前の状態機械に戻す').click()
    assert '以前の状態機械へ戻しました' in p.locator('#panelBody .listentry').last.inner_text()
    p.locator('#closePanel').click()
    send(p,'/flow')
    assert '待機' in p.locator('#messages').inner_text()
    # Export audit and compiled rules
    p.locator('#menu').click()
    with p.expect_download() as info:p.locator('#exportJson').click()
    snap=json.loads(Path(info.value.path()).read_text('utf-8'))
    assert snap['app_version']=='0.7.0'
    assert len(snap['bulk']['rules'])==3
    assert snap['autoAudit']['decision']=='不合格'
    assert snap['flowPrevious'] is None
    # Browser local storage still contains model after reload
    p.set_content(HTML)
    send(p,'計算をお願いします')
    assert 'WSP直接構築回路：auto_' in p.locator('#messages').inner_text()
    p.screenshot(path=str(ROOT/'artifacts'/'mobile_autodesign_v07.png'),full_page=True)
    # Previous WSP rules are persisted, so undo works after a full page reload.
    p.locator('#autoBtn').click()
    p.get_by_text('直前のルール採用を戻す').click()
    assert '直前の構成に戻しました' in p.locator('#panelBody .listentry').nth(1).inner_text()
    p.locator('#closePanel').click()
    send(p,'計算の結果を教えて')
    assert 'WSP直接構築回路：auto_' not in p.locator('#messages .message').last.inner_text()
    # Explicitly test v0.6 migration on another storage, without copying old-generated code
    ctx2=browser.new_context(viewport={'width':1280,'height':820})
    old=ctx2.new_page();old.set_default_timeout(8000)
    legacy=json.dumps({'schema':3,'chats':[{'id':'v06-chat','title':'旧会話','messages':[]}],
                       'current':'v06-chat','knowledge':[{'q':'遺産の問い','a':'旧データ保持'}],
                       'documents':[],'theme':'light'},ensure_ascii=False)
    attach_storage(old,{'solzero_chat_v06_local':legacy})
    old.set_content(HTML)
    send(old,'遺産の問い')
    assert '旧データ保持' in old.locator('#messages').inner_text()
    assert old.evaluate("localStorage.getItem('solzero_chat_v07_local') !== null")
    assert not errors,errors
    assert not net,net
    print(json.dumps({'auto_wsp':'PASS','heldout_reject':'PASS','atomic_deploy':'PASS',
      'flow_wsp':'PASS','rollback':'PASS','chat_integration':'PASS','backup':'PASS',
      'persist':'PASS','persistent_wsp_rollback':'PASS','v06_migration':'PASS','external_requests':len(net),'page_errors':errors},ensure_ascii=False))
    browser.close()
if __name__=='__main__':run()
