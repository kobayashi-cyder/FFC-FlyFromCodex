"""Offline Chromium smoke: learned weight route, old chat and no network."""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from threading import Thread
from functools import partial
from playwright.sync_api import sync_playwright

html=Path(__file__).resolve().parents[1]/'SolZero_Chat_Offline.html'
server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(html.parent)))
thread=Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path="/usr/bin/chromium",args=["--no-sandbox"])
    page=browser.new_page(viewport={'width':390,'height':844})
    errors=[]
    req=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.on('request',lambda r:req.append(r.url) if r.url.startswith(('http://','https://')) else None)
    page.goto(f"http://127.0.0.1:{server.server_port}/SolZero_Chat_Offline.html")
    page.locator('#input').fill('/intent この計算を解いて 19+7')
    page.locator('#send').click()
    response=page.locator('.message').last.inner_text()
    assert 'calc' in response, response
    page.locator('#input').fill('/learner')
    page.locator('#send').click()
    stats=page.locator('.message').last.inner_text()
    assert '24582' in stats or '24,582' in stats,stats
    assert not errors,errors
    assert not req,req
    page.screenshot(path=str(html.parent/'artifacts/browser_learned_mobile_v010.png'))
    print('PASS offline browser: learned command, stats, requests=0, errors=0')
    browser.close()

finally:
    server.shutdown()
