# v0.6 — WSP大量回路コンパイラ

- v0.5のHTMLチャット、Q&A、文書検索、文字予測、手動8×8 WSP回路を継承。
- `chat_web/wsp_bulk.js`：宣言的ルール→CSR風の疎な数値重み回路。AND/OR/NOT/exact、優先度、状態保存、単独重み編集、ロールバック、競合/不正入力の一括拒否。
- `chat_web/wsp_flow.js`：状態・イベントを2入力ReLU回路へコンパイル。イベント実行、巻き戻し、復元、監査履歴。外部OS操作は含まない。
- `chat_web/engine.js`：WSP応答ルーティング、`/wsp`と`/flow`のチャットコマンド。
- `chat_web/app.js`と`index.html`：WSP回路と状態機械のパネル、4,096件の規模試験ボタン、JSON保存形式にWSPを統合。
- `scripts/build_standalone.py`：新しいJavaScriptモジュールを自立HTMLに同梱。
- 33件JSテスト、6件Pythonテスト、Chromiumでの実操作・4,096件規模検証。

**非実装**：大規模スクラッチ学習、未知問題への汎用推論、Android実機RPA、音声・画像生成、Sol6.1級能力。
