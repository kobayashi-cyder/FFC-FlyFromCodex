# v0.8: Universal numerical WSP graph + disk-backed 4-bit weights

- Added arbitrary acyclic typed numerical graphs with bounded matrix shapes and real-valued inputs.
- Added direct matrix/bias weight edits, undo, JSON snapshots, chat command `/graph`, browser persistence.
- Added exact Boolean truth-table-to-ReLU synthesis: full 3-input parity table demonstrated.
- Added seeded dense network architecture initialization without imported weights.
- Added disk-backed signed int4 packed weight store, reversible atomic validated patches and durable undo journal.
- Added explicit memory/compute ceilings, no dynamic JS code evaluation and no network access.
- Migrated local storage from v0.7 and earlier versions.
- Fixed narrow phone toolbar layout to keep heading readable and tools horizontally scrollable.
- Preserved prior v0.7 automatic text feature synthesis, state machine, knowledge store, offline generator and chat.
- These are software engineering capabilities, not verified general intelligence.
